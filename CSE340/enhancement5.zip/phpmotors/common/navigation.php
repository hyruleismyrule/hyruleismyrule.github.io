<ul>
    <li>Home</li>
    <li>Classic</li>
    <li>Sports</li>
    <li>SUV</li>
    <li>Trucks</li>
    <li>Used</li>
</ul>