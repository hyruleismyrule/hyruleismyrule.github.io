<div class="copyright-container mobile-margin">
    <p>© PHP Motors, All rights reserved.</p>
    <p>All images used are believed to be in "Fair Use." Please notify the author if any are not and they
        will be removed.</p>
    <p>Lat Updated: <span id="last-updated"></span></p>
</div>