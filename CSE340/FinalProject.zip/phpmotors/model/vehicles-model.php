<?php
// This is the vehicles model

// Register a new classification
function regClassification($classificationName) {

    $db = phpmotorsConnect();

    $sql = 'INSERT INTO carclassification (classificationName)
    VALUES (:classificationName)';

    $stmt = $db->prepare($sql);

    $stmt->bindValue(':classificationName', $classificationName, PDO::PARAM_STR);

    $stmt->execute();

    $rowsChanged = $stmt->rowCount();

    $stmt->closeCursor();
 
    return $rowsChanged;
}


function regVehicle($invId, $invYear, $invMake, $invModel, $invDescription, $invPrice, $invMiles, $invColor, $classificationId) {
  
    $db = phpmotorsConnect();

    $sql = 'INSERT INTO inventory (invId, invYear, invMake, invModel, invDescription, invPrice, invMiles, invColor, classificationId)
        VALUES (:invId, :invYear, :invMake, :invModel, :invDescription, :invPrice, :invMiles, :invColor, :classificationId)';

    $stmt = $db->prepare($sql);

    $stmt->bindValue(':invId', $invId, PDO::PARAM_STR);
    $stmt->bindValue(':invMake', $invMake, PDO::PARAM_STR);
    $stmt->bindValue(':invModel', $invModel, PDO::PARAM_STR);
    $stmt->bindValue(':invDescription', $invDescription, PDO::PARAM_STR);
    $stmt->bindValue(':invPrice', $invPrice, PDO::PARAM_INT);
    $stmt->bindValue(':invYear', $invYear, PDO::PARAM_INT);
    $stmt->bindValue(':invMiles', $invMiles, PDO::PARAM_INT);
    $stmt->bindValue(':invColor', $invColor, PDO::PARAM_STR);
    $stmt->bindValue(':classificationId', $classificationId, PDO::PARAM_INT);

    $stmt->execute();
 
    $rowsChanged = $stmt->rowCount();

    $stmt->closeCursor();

    return $rowsChanged;
}

// Get vehicles by classificationId 
function getInventoryByClassification($classificationId){ 
    $db = phpmotorsConnect(); 
    $sql = ' SELECT * FROM inventory WHERE classificationId = :classificationId'; 
    $stmt = $db->prepare($sql); 
    $stmt->bindValue(':classificationId', $classificationId, PDO::PARAM_INT); 
    $stmt->execute(); 
    $inventory = $stmt->fetchAll(PDO::FETCH_ASSOC); 
    $stmt->closeCursor(); 
    return $inventory; 
}

// Get vehicle information by invId
function getInvItemInfo($invId){
    $db = phpmotorsConnect();
    $sql = 'SELECT * FROM inventory WHERE invId = :invId';
    $stmt = $db->prepare($sql);

    $stmt->bindValue(':invId', $invId, PDO::PARAM_STR);
    $stmt->execute();
    $invInfo = $stmt->fetch(PDO::FETCH_ASSOC);
    $stmt->closeCursor();
    return $invInfo;
}

// Use classificationId to get classification name
function getclassificationName($classificationId) {
    $db = phpmotorsConnect();
    $sql = 'SELECT classificationName FROM carclassification WHERE classificationId = :classificationId';
    $stmt = $db->prepare($sql);
    $stmt->bindValue(':classificationId', $classificationId, PDO::PARAM_INT);
    $stmt->execute();
    $classificationName = $stmt->fetch(PDO::FETCH_ASSOC);
    $stmt->closeCursor();
    return $classificationName;
}

// Update a vehicle
function updateVehicle($invMake, $invModel, $invDescription, $invPrice, $invMiles, $invColor, $classificationId, $invId) {
   
    $db = phpmotorsConnect();

    $sql = 'UPDATE inventory SET invMake = :invMake, invModel = :invModel, invDescription = :invDescription, invPrice = :invPrice, invMiles = :invMiles, invColor = :invColor, classificationId = :classificationId WHERE invId = :invId';
    
    $stmt = $db->prepare($sql);
    
    $stmt->bindValue(':classificationId', $classificationId, PDO::PARAM_INT);
    $stmt->bindValue(':invMake', $invMake, PDO::PARAM_STR);
    $stmt->bindValue(':invModel', $invModel, PDO::PARAM_STR);
    $stmt->bindValue(':invDescription', $invDescription, PDO::PARAM_STR);
 
    $stmt->bindValue(':invPrice', $invPrice, PDO::PARAM_STR);
    $stmt->bindValue(':invMiles', $invMiles, PDO::PARAM_INT);
    $stmt->bindValue(':invColor', $invColor, PDO::PARAM_STR);

    $stmt->bindValue(':invId', $invId, PDO::PARAM_STR);
    
    $stmt->execute();
    
    $rowsChanged = $stmt->rowCount();
    
    $stmt->closeCursor();
    
    return $rowsChanged;
}

function deleteVehicle($invId) {
    $db = phpmotorsConnect();
    $sql = 'DELETE FROM inventory WHERE invId = :invId';
    $stmt = $db->prepare($sql);
 
    $stmt->bindValue(':invId', $invId, PDO::PARAM_STR);
    $stmt->execute();
    $rowsChanged = $stmt->rowCount();
    $stmt->closeCursor();
    return $rowsChanged;
}

// Gets the classification id from the classification name
function getVehiclesByClassification($classificationName){
    $db = phpmotorsConnect();
    // Join the inventory table to the images table
    $sql = 
    "SELECT * 
    FROM inventory iv 
    INNER JOIN images im 
    ON iv.invId = im.invId 
    WHERE classificationId LIKE
        (SELECT classificationId FROM carclassification 
        WHERE classificationName = :classificationName)
    AND im.imgName LIKE '%-tn.%'
    ";
    
    $stmt = $db->prepare($sql);
    $stmt->bindValue(':classificationName', $classificationName, PDO::PARAM_STR);
    $stmt->execute();
    $vehicles = $stmt->fetchAll(PDO::FETCH_ASSOC);
    $stmt->closeCursor();
    return $vehicles;
}

// Gets the classification id from the classification name
function getAllVehicleInfo($invId) {
    $db = phpmotorsConnect();
    // Join the inventory table to the images table
    $sql = 
    "SELECT * 
    FROM inventory iv 
    INNER JOIN images im 
    ON iv.invId = im.invId 
    WHERE iv.invId = :invId
    AND im.imgName LIKE '%-tn.%'
    ";
    
    $stmt = $db->prepare($sql);
    $stmt->bindValue(':invId', $invId, PDO::PARAM_STR);
    $stmt->execute();
    $vehicle = $stmt->fetch(PDO::FETCH_ASSOC);
    $stmt->closeCursor();
    return $vehicle;
}

// Get information for all vehicles
function getVehicles(){
	$db = phpmotorsConnect();
	$sql = 'SELECT invId, invMake, invModel FROM inventory';
	$stmt = $db->prepare($sql);
	$stmt->execute();
	$invInfo = $stmt->fetchAll(PDO::FETCH_ASSOC);
	$stmt->closeCursor();
	return $invInfo;
}

// Use classificationId to get classification name
function getPrimaryImg($invId) {
    $db = phpmotorsConnect();
    // $sql = "SELECT imgPath FROM images WHERE invId = :invId AND imgPrimary = 1 AND imgName NOT LIKE '%-tn.%'";
    $sql = "SELECT imgPath FROM images WHERE invId = :invId AND imgName NOT LIKE '%-tn.%'";
    $stmt = $db->prepare($sql);

    $stmt->bindValue(':invId', $invId, PDO::PARAM_STR);
    $stmt->execute();
    $imgPath = $stmt->fetch(PDO::FETCH_ASSOC);
    $stmt->closeCursor();
    return $imgPath;
}

function getImgThumbnails($invId) {
    $db = phpmotorsConnect();

    $sql = "SELECT imgPath FROM images WHERE invId = :invId AND imgName LIKE '%-tn.%'";
    $stmt = $db->prepare($sql);

    $stmt->bindValue(':invId', $invId, PDO::PARAM_STR);
    $stmt->execute();
    $imgThumbnailArray = $stmt->fetchAll(PDO::FETCH_ASSOC);
    $stmt->closeCursor();
    return $imgThumbnailArray;
}

// Because of the new database I need to make sure that the generated Id is not already in the database
function checkForExistingId($invId) {
    $db = phpmotorsConnect();
    $sql = "SELECT invId FROM inventory WHERE invId = :invId";
    $stmt = $db->prepare($sql);
    $stmt->bindValue(':invId', $invId, PDO::PARAM_STR);
    $stmt->execute();
    $databaseId = $stmt->fetch(PDO::FETCH_ASSOC);
    $stmt->closeCursor();
    return $databaseId;
}