<?php
// This is the seach model

function searchMake($searchTerm) {
    $searchTerm = '%'.$searchTerm.'%';
    $db = phpmotorsConnect();
    $sql = 
    "SELECT invId
    FROM inventory
    WHERE invMake LIKE :searchTerm
    ";
    $stmt = $db->prepare($sql);
    $stmt->bindValue(':searchTerm', $searchTerm, PDO::PARAM_STR);
    $stmt->execute();
    $vehicleIds = $stmt->fetchAll(PDO::FETCH_ASSOC);
    $stmt->closeCursor();
    return $vehicleIds;
}

function searchModel($searchTerm) {
    $searchTerm = '%'.$searchTerm.'%';
    $db = phpmotorsConnect();
    $sql = 
    "SELECT invId
    FROM inventory
    WHERE invModel LIKE :searchTerm
    ";
    $stmt = $db->prepare($sql);
    $stmt->bindValue(':searchTerm', $searchTerm, PDO::PARAM_STR);
    $stmt->execute();
    $vehicleIds = $stmt->fetchAll(PDO::FETCH_ASSOC);
    $stmt->closeCursor();
    return $vehicleIds;
}

function searchDescription($searchTerm) {
    $searchTerm = '%'.$searchTerm.'%';
    $db = phpmotorsConnect();
    $sql = 
    "SELECT invId
    FROM inventory
    WHERE invDescription LIKE :searchTerm
    ";
    $stmt = $db->prepare($sql);
    $stmt->bindValue(':searchTerm', $searchTerm, PDO::PARAM_STR);
    $stmt->execute();
    $vehicleIds = $stmt->fetchAll(PDO::FETCH_ASSOC);
    $stmt->closeCursor();
    return $vehicleIds;
}

function getClassificationId($searchTerm) {
    $searchTerm = '%'.$searchTerm.'%';
    $db = phpmotorsConnect();
    $sql = 
    "SELECT classificationId
    FROM carclassification
    WHERE classificationName LIKE :searchTerm
    ";
    $stmt = $db->prepare($sql);
    $stmt->bindValue(':searchTerm', $searchTerm, PDO::PARAM_STR);
    $stmt->execute();
    $classificationIds = $stmt->fetch(PDO::FETCH_ASSOC);
    $stmt->closeCursor();
    return $classificationIds;
}

function searchClassification($searchedClassificationId) {
    $db = phpmotorsConnect();
    $sql = 
    "SELECT invId
    FROM inventory
    WHERE classificationId = :classificationId
    ";
    $stmt = $db->prepare($sql);
    $stmt->bindValue(':classificationId', $searchedClassificationId, PDO::PARAM_INT);
    $stmt->execute();
    $vehicleIds = $stmt->fetchAll(PDO::FETCH_ASSOC);
    $stmt->closeCursor();
    return $vehicleIds;
}

function searchColor($searchTerm) {
    $searchTerm = '%'.$searchTerm.'%';
    $db = phpmotorsConnect();
    $sql = 
    "SELECT invId
    FROM inventory
    WHERE invColor LIKE :searchTerm
    ";
    $stmt = $db->prepare($sql);
    $stmt->bindValue(':searchTerm', $searchTerm, PDO::PARAM_STR);
    $stmt->execute();
    $vehicleIds = $stmt->fetchAll(PDO::FETCH_ASSOC);
    $stmt->closeCursor();
    return $vehicleIds;
}

function searchPrice($int_searchTerm) {
    $db = phpmotorsConnect();
    // I want a range of $5,000 above and below
    $high = $int_searchTerm + 5000;
    $low = $int_searchTerm - 5000;
    $sql = 
    "SELECT invId
    FROM inventory
    WHERE invPrice BETWEEN :low AND :high
    ";
    $stmt = $db->prepare($sql);
    $stmt->bindValue(':high', $high, PDO::PARAM_INT);
    $stmt->bindValue(':low', $low, PDO::PARAM_INT);
    $stmt->execute();
    $vehicleIds = $stmt->fetchAll(PDO::FETCH_ASSOC);
    $stmt->closeCursor();
    return $vehicleIds;
}

function searchMiles($int_searchTerm) {
    $db = phpmotorsConnect();
    // I want a range of $15,000 above and below
    $high = $int_searchTerm + 15000;
    $low = $int_searchTerm - 15000;
    $sql = 
    "SELECT invId
    FROM inventory
    WHERE invMiles BETWEEN :low AND :high
    ";
    $stmt = $db->prepare($sql);
    $stmt->bindValue(':high', $high, PDO::PARAM_INT);
    $stmt->bindValue(':low', $low, PDO::PARAM_INT);
    $stmt->execute();
    $vehicleIds = $stmt->fetchAll(PDO::FETCH_ASSOC);
    $stmt->closeCursor();
    return $vehicleIds;
}

function searchYear($int_searchTerm) {
    $db = phpmotorsConnect();
    $sql = 
    "SELECT invId
    FROM inventory
    WHERE invYear = :searchTerm
    ";
    $stmt = $db->prepare($sql);
    $stmt->bindValue(':searchTerm', $int_searchTerm, PDO::PARAM_INT);
    $stmt->execute();
    $vehicleIds = $stmt->fetchAll(PDO::FETCH_ASSOC);
    $stmt->closeCursor();
    return $vehicleIds;
}

// Get vehicle information by invId
function getInvItemInfo($invId){
    $db = phpmotorsConnect();
    // $sql = 'SELECT * FROM inventory WHERE invId = :invId';
    $sql =
    "SELECT * 
    FROM inventory iv 
    INNER JOIN images im 
    ON iv.invId = im.invId 
    WHERE iv.invId = :invId
    AND im.imgName LIKE '%-tn.%'
    ";
    $stmt = $db->prepare($sql);

    $stmt->bindValue(':invId', $invId, PDO::PARAM_STR);
    $stmt->execute();
    $invInfo = $stmt->fetch(PDO::FETCH_ASSOC);
    $stmt->closeCursor();
    return $invInfo;
}