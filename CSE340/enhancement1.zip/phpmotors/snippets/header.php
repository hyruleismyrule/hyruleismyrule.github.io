<div class="logo-container">
    <img src="images/site/logo.png" alt="PHP Motors">
</div>
<div class="account-container">
    <p>My Account</p>
</div>