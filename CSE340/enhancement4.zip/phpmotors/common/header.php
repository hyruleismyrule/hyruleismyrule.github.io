<div class="logo-container">
    <img src="/phpmotors/images/site/logo.png" alt="PHP Motors">
</div>
<div class="account-container">
    <a href="/phpmotors/accounts?action=login" title="Login or Register with PHP Motors" id="acc">My Account</a>
</div>